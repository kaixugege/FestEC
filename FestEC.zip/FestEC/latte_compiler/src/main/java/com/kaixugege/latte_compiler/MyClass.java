package com.kaixugege.latte_compiler;

public class MyClass {
}
