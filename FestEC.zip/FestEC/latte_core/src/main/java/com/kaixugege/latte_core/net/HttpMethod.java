package com.kaixugege.latte_core.net;

/**
 * @Author: KaixuGege
 * Time:           2019/1/31
 * ProjectName:    FestEC
 * ClassName:
 * Info:
 */
public enum HttpMethod {
    GET, POST, PUT, DELETE
}
