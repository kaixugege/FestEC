package com.kaixugege.latte_core.delegates;

import android.widget.BaseAdapter;

/**
 * @Author: KaixuGege
 * Time:           2019/1/30
 * ProjectName:    FestEC
 * ClassName:
 * Info:权限检测的 类
 */
public abstract class PermissionCheckerDelegate extends BaseDelegate {
}
