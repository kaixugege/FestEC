package com.kaixugege.latte_core.delegates;


/**
 * @Author: KaixuGege
 * Time:           2019/1/30
 * ProjectName:    FestEC
 * ClassName:
 * Info:正式使用的类
 */
public abstract class LatteDelegate extends PermissionCheckerDelegate {



}
