package com.kaixugege.latte_annotations;

public class MyClass {
}
